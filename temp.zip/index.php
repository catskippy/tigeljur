<?php
session_start();

// Проверяем, авторизован ли пользователь, и получаем его имя из сессии
if (isset($_SESSION["username"])) {
    $username = $_SESSION["username"];
} else {
    // Если пользователь не авторизован, перенаправляем на страницу входа
    header("Location: login.php");
    exit; // Завершаем выполнение текущей страницы
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="styles.css"> <!-- Подключите ваш файл CSS -->
    <title>Электронный журнал "Tigerya"</title>
</head>
<body>
    <header>
        <h1>Информация о Электронном журнале "Tigerya"</h1>
        <p>Привет, <?php echo $username; ?></p>
    </header>

    <section class="school-screens">
        <h2>Школа "Tigerya"</h2>
        <div class="screenshots-container">
            <?php
            $screenshots = array(
                "screenshot1.jpg",
                "screenshot2.jpg",
                "screenshot3.jpg"
            );
            foreach ($screenshots as $screenshot) {
                echo '<div class="screenshot">';
                echo '<img src="' . $screenshot . '" alt="Скриншот">';
                echo '</div>';
            }
            ?>
        </div>
    </section>

    <section class="action-buttons">
        <a href="personal-cabinet.php" class="btn">Личный кабинет</a>
        <a href="schedule.php" class="btn">Расписание</a>
        <a href="student-grades.php" class="btn">Оценки ученика</a>
    </section>
</body>
</html>
