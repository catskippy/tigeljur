<?php
session_start();

// Проверяем, авторизован ли пользователь, и получаем его имя из сессии
if (isset($_SESSION["username"])) {
    $username = $_SESSION["username"];
} else {
    // Если пользователь не авторизован, перенаправляем на страницу входа
    header("Location: login.php");
    exit; // Завершаем выполнение текущей страницы
}

// Подключение к базе данных
$db = new mysqli("localhost", "admin", "admin", "tigerya");

// Проверка подключения к базе данных
if ($db->connect_error) {
    die("Ошибка подключения к базе данных: " . $db->connect_error);
}

// Запрос для получения оценок пользователя из базы данных
$query = "SELECT subject, grade FROM user_grades WHERE username='$username'";
$result = $db->query($query);

// Подготовьте данные оценок из результата запроса
$grades = array();
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $subject = $row["subject"];
        $grade = $row["grade"];
        $grades[$subject] = $grade;
    }
}

// Закрыть соединение с базой данных
$db->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="styles.css"> <!-- Подключите ваш файл CSS -->
    <title>Личный кабинет</title>
</head>
<body>
    <header>
        <h1>Личный кабинет пользователя: <?php echo $username; ?></h1>
    </header>

    <section class="grades">
        <div class="grades-block">
            <h2>Оценки по предметам</h2>
            <table>
                <tr>
                    <th>Предмет</th>
                    <th>Оценка</th>
                </tr>
                <?php
                foreach ($grades as $subject => $grade) {
                    echo '<tr>';
                    echo '<td>' . $subject . '</td>';
                    echo '<td>' . $grade . '</td>';
                    echo '</tr>';
                }
                ?>
            </table>
        </div>
    </section>
</body>
</html>
