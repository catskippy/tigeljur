--оздание таблицы user_grades
CREATE TABLE user_grades (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(255) NOT NULL,
    subject VARCHAR(255) NOT NULL,
    grade INT NOT NULL,
    -- Другие поля оценки

    -- Создание внешнего ключа, связанного с таблицей users
    CONSTRAINT fk_username
    FOREIGN KEY (username) REFERENCES users(username)
);
