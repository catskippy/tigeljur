<?php
session_start();

// Проверяем, авторизован ли пользователь
if (isset($_SESSION["username"])) {
    // Если пользователь авторизован, разрушаем сессию и перенаправляем на страницу входа
    session_destroy();
    header("Location: login.php");
} else {
    // Если пользователь не авторизован, перенаправляем на страницу входа
    header("Location: login.php");
}
?>
