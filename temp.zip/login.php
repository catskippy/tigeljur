<?php
session_start();
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Обработка данных из формы входа
    $username = $_POST["username"];
    $password = $_POST["password"];
    // Подключение к базе данных и выполнение SQL-запроса для проверки учетных данных
    $db = new mysqli("localhost", "admin", "admin", "tigerya");
    $query = "SELECT * FROM users WHERE username='$username' AND password='$password'";
    $result = $db->query($query);
    if ($result->num_rows == 1) {
        // Успешный вход
        $_SESSION["username"] = $username;
        header("Location: index.php");
    } else {
        echo "Неправильное имя пользователя или пароль.";
    }
    $db->close();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Вход</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #E0F4FF;
            text-align: center;
        }
        
        h2 {
            color: #39A7FF;
        }
        
        .container {
            background-color: #fff;
            border-radius: 10px;
            width: 300px;
            margin: 0 auto;
            padding: 20px;
        }
        
        .input-field {
            margin: 10px 0;
            text-align: left;
        }
        
        .input-field input {
            width: 100%;
            padding: 10px;
            border: 1px solid #87C4FF;
            border-radius: 5px;
        }
        
        .input-field input:focus {
            outline: none;
        }
        
        .submit-btn {
            background-color: #87C4FF;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <h2>Вход</h2>
    <div class="container">
        <form method="post" action="login.php">
            <div class="input-field">
                <input type="text" name="username" placeholder="Имя пользователя" required>
            </div>
            <div class="input-field">
                <input type="password" name="password" placeholder="Пароль" required>
            </div>
            <button type="submit" class="submit-btn">Войти</button>
        </form>
    </div>
</body>
</html>